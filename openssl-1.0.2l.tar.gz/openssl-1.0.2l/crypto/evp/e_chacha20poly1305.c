/* ====================================================================
 * Copyright (c) 2013 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.openssl.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    openssl-core@openssl.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.openssl.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 */
/* Copyright (c) 2014, Google Inc.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */

#include <stdint.h>
#include <string.h>
#include <openssl/opensslconf.h>

#if !defined(OPENSSL_NO_CHACHA) && !defined(OPENSSL_NO_POLY1305)

#include <openssl/chacha.h>
#include <openssl/poly1305.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include "evp_locl.h"

#define POLY1305_TAG_LEN 16
#define CHACHA20_NONCE_LEN 12
#define CHACHA20_NONCE_LEN_OLD 8

struct aead_chacha20_poly1305_ctx
	{
	unsigned char key[32];
	unsigned tag_len;
	};

static int aead_chacha20_poly1305_init(EVP_AEAD_CTX *ctx, const unsigned char *key, size_t key_len, size_t tag_len)
	{
	struct aead_chacha20_poly1305_ctx *c20_ctx;

	if (tag_len == 0)
		tag_len = POLY1305_TAG_LEN;

	if (tag_len > POLY1305_TAG_LEN)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_INIT, EVP_R_TOO_LARGE);
		return 0;
		}

	if (key_len != sizeof(c20_ctx->key))
		return 0;  /* internal error - EVP_AEAD_CTX_init should catch this. */

	c20_ctx = OPENSSL_malloc(sizeof(struct aead_chacha20_poly1305_ctx));
	if (c20_ctx == NULL)
		return 0;

	memcpy(&c20_ctx->key[0], key, key_len);
	c20_ctx->tag_len = tag_len;
	ctx->aead_state = c20_ctx;

	return 1;
	}

static void aead_chacha20_poly1305_cleanup(EVP_AEAD_CTX *ctx)
	{
	struct aead_chacha20_poly1305_ctx *c20_ctx = ctx->aead_state;
	OPENSSL_cleanse(c20_ctx->key, sizeof(c20_ctx->key));
	OPENSSL_free(c20_ctx);
	}

static void poly1305_init_key(poly1305_state *poly1305, uint8_t *poly1305_key,
			      const uint8_t *c20_key, const uint8_t *nonce)
	{
	memset(poly1305_key, 0, 32);
	CRYPTO_chacha_20(poly1305_key, poly1305_key, 32, c20_key, nonce, 0);
	CRYPTO_poly1305_init(poly1305, poly1305_key);
	}

static void poly1305_update_length(poly1305_state *poly1305, size_t data_len)
	{
	unsigned char length_bytes[8];
	unsigned i;

	for (i = 0; i < sizeof(length_bytes); i++)
		{
		length_bytes[i] = data_len;
		data_len >>= 8;
		}

	CRYPTO_poly1305_update(poly1305, length_bytes, sizeof(length_bytes));
	}

static void poly1305_update_with_length(poly1305_state *poly1305,
	const unsigned char *data, size_t data_len)
	{
	CRYPTO_poly1305_update(poly1305, data, data_len);
	poly1305_update_length(poly1305, data_len);
	}

#ifdef __arm__
#define ALIGNED __attribute__((aligned(16)))
#else
#define ALIGNED
#endif

static int aead_chacha20_poly1305_old_seal(const EVP_AEAD_CTX *ctx,
	unsigned char *out, size_t *out_len, size_t max_out_len,
	const unsigned char *nonce, size_t nonce_len,
	const unsigned char *in, size_t in_len,
	const unsigned char *ad, size_t ad_len)
	{
	const struct aead_chacha20_poly1305_ctx *c20_ctx = ctx->aead_state;
	unsigned char poly1305_key[32] ALIGNED;
	poly1305_state poly1305;
	const uint64_t in_len_64 = in_len;
	union { uint32_t i[3]; unsigned char nonce[CHACHA20_NONCE_LEN]; } u;
	unsigned char tag[POLY1305_TAG_LEN];

	/* |CRYPTO_chacha_20| uses a 32-bit block counter. Therefore we disallow
	 * individual operations that work on more than 256GB at a time.
	 * |in_len_64| is needed because, on 32-bit platforms, size_t is only
	 * 32-bits and this produces a warning because it's always false.
	 * Casting to uint64_t inside the conditional is not sufficient to stop
	 * the warning. */
	if (in_len_64 >= (1ull << 32)*64-64)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_TOO_LARGE);
		return 0;
		}

	if (in_len + c20_ctx->tag_len < in_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_TOO_LARGE);
		return 0;
		}

	if (max_out_len < in_len + c20_ctx->tag_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_BUFFER_TOO_SMALL);
		return 0;
		}

	if (nonce_len != CHACHA20_NONCE_LEN_OLD)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_IV_TOO_LARGE);
		return 0;
		}

	u.i[0] = 0;
	memcpy(&u.i[1], nonce, CHACHA20_NONCE_LEN_OLD);
	poly1305_init_key(&poly1305, poly1305_key, c20_ctx->key, &u.nonce[0]);
	poly1305_update_with_length(&poly1305, ad, ad_len);
	CRYPTO_chacha_20(out, in, in_len, c20_ctx->key, &u.nonce[0], 1);
	poly1305_update_with_length(&poly1305, out, in_len);
	CRYPTO_poly1305_finish(&poly1305, tag);

	memcpy(out + in_len, tag, c20_ctx->tag_len);
	*out_len = in_len + c20_ctx->tag_len;
	return 1;
	}

static int aead_chacha20_poly1305_old_open(const EVP_AEAD_CTX *ctx,
	unsigned char *out, size_t *out_len, size_t max_out_len,
	const unsigned char *nonce, size_t nonce_len,
	const unsigned char *in, size_t in_len,
	const unsigned char *ad, size_t ad_len)
	{
	const struct aead_chacha20_poly1305_ctx *c20_ctx = ctx->aead_state;
	unsigned char mac[POLY1305_TAG_LEN];
	unsigned char poly1305_key[32] ALIGNED;
	poly1305_state poly1305;
	const uint64_t in_len_64 = in_len;
	size_t plaintext_len;
	union { uint32_t i[3]; unsigned char nonce[CHACHA20_NONCE_LEN]; } u;

	if (in_len < c20_ctx->tag_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BAD_DECRYPT);
		return 0;
		}

	/* |CRYPTO_chacha_20| uses a 32-bit block counter. Therefore we disallow
	 * individual operations that work on more than 256GB at a time.
	 * |in_len_64| is needed because, on 32-bit platforms, size_t is only
	 * 32-bits and this produces a warning because it's always false.
	 * Casting to uint64_t inside the conditional is not sufficient to stop
	 * the warning. */
	if (in_len_64 >= (1ull << 32)*64-64)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_TOO_LARGE);
		return 0;
		}

	if (nonce_len != CHACHA20_NONCE_LEN_OLD)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_IV_TOO_LARGE);
		return 0;
		}

	plaintext_len = in_len - c20_ctx->tag_len;

	if (max_out_len < plaintext_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BUFFER_TOO_SMALL);
		return 0;
		}

	u.i[0] = 0;
	memcpy(&u.i[1], nonce, CHACHA20_NONCE_LEN_OLD);
	poly1305_init_key(&poly1305, poly1305_key, c20_ctx->key, &u.nonce[0]);
	poly1305_update_with_length(&poly1305, ad, ad_len);
	poly1305_update_with_length(&poly1305, in, plaintext_len);
	CRYPTO_poly1305_finish(&poly1305, mac);

	if (CRYPTO_memcmp(mac, in + plaintext_len, c20_ctx->tag_len) != 0)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BAD_DECRYPT);
		return 0;
		}

	CRYPTO_chacha_20(out, in, plaintext_len, c20_ctx->key, &u.nonce[0], 1);
	*out_len = plaintext_len;
	return 1;
	}

static const EVP_AEAD aead_chacha20_poly1305_old =
	{
	32,  /* key len */
	CHACHA20_NONCE_LEN_OLD, /* nonce len */
	POLY1305_TAG_LEN,  /* overhead */
	POLY1305_TAG_LEN,  /* max tag length */

	aead_chacha20_poly1305_init,
	aead_chacha20_poly1305_cleanup,
	aead_chacha20_poly1305_old_seal,
	aead_chacha20_poly1305_old_open,
	};

const EVP_AEAD *EVP_aead_chacha20_poly1305_old()
	{
	return &aead_chacha20_poly1305_old;
	}

/*
 *  Functions for the RFC 7539
 */
static void poly1305_update_padded_16(poly1305_state *poly1305,
				      const uint8_t *data, size_t data_len)
	{
	static const uint8_t padding[16] = { 0 }; /* Padding is all zeros. */

	CRYPTO_poly1305_update(poly1305, data, data_len);
	if (data_len % 16 != 0)
		CRYPTO_poly1305_update(poly1305, padding,
				       sizeof(padding) - (data_len % 16));
	}

static int aead_chacha20_poly1305_seal(const EVP_AEAD_CTX *ctx, uint8_t *out,
				       size_t *out_len, size_t max_out_len,
				       const uint8_t *nonce, size_t nonce_len,
				       const uint8_t *in, size_t in_len,
				       const uint8_t *ad, size_t ad_len)
	{
	const struct aead_chacha20_poly1305_ctx *c20_ctx = ctx->aead_state;
	uint8_t tag[POLY1305_TAG_LEN];
	uint8_t poly1305_key[32] ALIGNED;
	poly1305_state poly1305;
	const uint64_t in_len_64 = in_len;

	/* |CRYPTO_chacha_20| uses a 32-bit block counter. Therefore we disallow
	 * individual operations that work on more than 256GB at a time.
	 * |in_len_64| is needed because, on 32-bit platforms, size_t is only
	 * 32-bits and this produces a warning because it's always false.
	 * Casting to uint64_t inside the conditional is not sufficient to stop
	 * the warning. */
	if (in_len_64 >= (1ull << 32) * 64 - 64)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_TOO_LARGE);
		return 0;
		}

	if (in_len + c20_ctx->tag_len < in_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_TOO_LARGE);
		return 0;
		}

	if (max_out_len < in_len + c20_ctx->tag_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_BUFFER_TOO_SMALL);
		return 0;
		}

	if (nonce_len != CHACHA20_NONCE_LEN)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_SEAL, EVP_R_IV_TOO_LARGE);
		return 0;
		}

	CRYPTO_chacha_20(out, in, in_len, c20_ctx->key, nonce, 1);

	poly1305_init_key(&poly1305, poly1305_key, c20_ctx->key, nonce);
	poly1305_update_padded_16(&poly1305, ad, ad_len);
	poly1305_update_padded_16(&poly1305, out, in_len);
	poly1305_update_length(&poly1305, ad_len);
	poly1305_update_length(&poly1305, in_len);
	CRYPTO_poly1305_finish(&poly1305, tag);

	memcpy(out + in_len, tag, c20_ctx->tag_len);
	*out_len = in_len + c20_ctx->tag_len;
	return 1;
	}

static int aead_chacha20_poly1305_open(const EVP_AEAD_CTX *ctx, uint8_t *out,
				       size_t *out_len, size_t max_out_len,
				       const uint8_t *nonce, size_t nonce_len,
				       const uint8_t *in, size_t in_len,
				       const uint8_t *ad, size_t ad_len)
	{
	const struct aead_chacha20_poly1305_ctx *c20_ctx = ctx->aead_state;
	uint8_t tag[POLY1305_TAG_LEN];
	uint8_t poly1305_key[32] ALIGNED;
	poly1305_state poly1305;
	const uint64_t in_len_64 = in_len;
	size_t plaintext_len;

	if (in_len < c20_ctx->tag_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BAD_DECRYPT);
		return 0;
		}

	/* |CRYPTO_chacha_20| uses a 32-bit block counter. Therefore we disallow
	 * individual operations that work on more than 256GB at a time.
	 * |in_len_64| is needed because, on 32-bit platforms, size_t is only
	 * 32-bits and this produces a warning because it's always false.
	 * Casting to uint64_t inside the conditional is not sufficient to stop
	 * the warning. */
	if (in_len_64 >= (1ull << 32) * 64 - 64)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_TOO_LARGE);
		return 0;
		}

	if (nonce_len != CHACHA20_NONCE_LEN)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_IV_TOO_LARGE);
		return 0;
		}

	plaintext_len = in_len - c20_ctx->tag_len;

	if (max_out_len < plaintext_len)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BUFFER_TOO_SMALL);
		return 0;
		}

	poly1305_init_key(&poly1305, poly1305_key, c20_ctx->key, nonce);
	poly1305_update_padded_16(&poly1305, ad, ad_len);
	poly1305_update_padded_16(&poly1305, in, plaintext_len);
	poly1305_update_length(&poly1305, ad_len);
	poly1305_update_length(&poly1305, plaintext_len);
	CRYPTO_poly1305_finish(&poly1305, tag);

	if (CRYPTO_memcmp(tag, in + plaintext_len, c20_ctx->tag_len) != 0)
		{
		EVPerr(EVP_F_AEAD_CHACHA20_POLY1305_OPEN, EVP_R_BAD_DECRYPT);
		return 0;
		}

	CRYPTO_chacha_20(out, in, plaintext_len, c20_ctx->key, nonce, 1);
	*out_len = plaintext_len;
	return 1;
	}

static const EVP_AEAD aead_chacha20_poly1305 =
	{
	32,			/* key len */
	CHACHA20_NONCE_LEN,	/* nonce len */
	POLY1305_TAG_LEN,	/* overhead */
	POLY1305_TAG_LEN,	/* max tag length */

	aead_chacha20_poly1305_init,
	aead_chacha20_poly1305_cleanup,
	aead_chacha20_poly1305_seal,
	aead_chacha20_poly1305_open,
	};

const EVP_AEAD *EVP_aead_chacha20_poly1305_rfc7539()
	{
	return &aead_chacha20_poly1305;
	}

const EVP_AEAD *EVP_aead_chacha20_poly1305()
	{
	return &aead_chacha20_poly1305;
	}

#endif  /* !OPENSSL_NO_CHACHA && !OPENSSL_NO_POLY1305 */
